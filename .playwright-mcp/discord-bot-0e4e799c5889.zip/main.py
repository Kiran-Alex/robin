import discord
from discord.ext import commands
import json
import os
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Bot configuration
TOKEN = os.getenv('TOKEN')
intents = discord.Intents.default()
intents.message_content = True

# Initialize bot
bot = commands.Bot(command_prefix='!', intents=intents, help_command=None)

# Load data from JSON file
def load_data():
    try:
        with open('data.json', 'r') as f:
            return json.load(f)
    except FileNotFoundError:
        return {'users': {}, 'welcome_messages': {}}

# Save data to JSON file
def save_data(data):
    with open('data.json', 'w') as f:
        json.dump(data, f, indent=4)

data = load_data()

# Event to indicate the bot is ready
@bot.event
async def on_ready():
    print(f'{bot.user.name} has connected to Discord!')

# Custom help command
@bot.command()
async def help(ctx):
    embed = discord.Embed(title='Moderation Commands', color=discord.Color.blue())
    embed.add_field(name='!ping', value='Shows bot latency', inline=False)
    embed.add_field(name='!kick <user>', value='Kicks a user from the server', inline=False)
    embed.add_field(name='!ban <user>', value='Bans a user from the server', inline=False)
    embed.add_field(name='!mute <user>', value='Mutes a user in the server', inline=False)
    embed.add_field(name='!unmute <user>', value='Unmutes a muted user', inline=False)
    embed.add_field(name='!warn <user>', value='Warns a user', inline=False)
    embed.add_field(name='!welcome <message>', value='Sets welcome message for new users', inline=False)
    await ctx.send(embed=embed)

# Ping command to show bot latency
@bot.command()
async def ping(ctx):
    latency = round(bot.latency * 1000)
    await ctx.send(f'Pong! Latency: {latency} ms')

# Kick command
@bot.command()
@commands.has_permissions(kick_members=True)
async def kick(ctx, member: discord.Member, *, reason=None):
    if member == ctx.author:
        await ctx.send('You cannot kick yourself!')
        return
    await member.kick(reason=reason)
    await ctx.send(f'{member.name} has been kicked')

# Ban command
@bot.command()
@commands.has_permissions(ban_members=True)
async def ban(ctx, member: discord.Member, *, reason=None):
    if member == ctx.author:
        await ctx.send('You cannot ban yourself!')
        return
    await member.ban(reason=reason)
    await ctx.send(f'{member.name} has been banned')

# Mute command
@bot.command()
@commands.has_permissions(manage_roles=True)
async def mute(ctx, member: discord.Member):
    if member == ctx.author:
        await ctx.send('You cannot mute yourself!')
        return
    
    # Check if muted role exists, if not create it
    muted_role = discord.utils.get(ctx.guild.roles, name='Muted')
    if not muted_role:
        muted_role = await ctx.guild.create_role(name='Muted')
        for channel in ctx.guild.channels:
            await channel.set_permissions(muted_role, send_messages=False)
    
    await member.add_roles(muted_role)
    await ctx.send(f'{member.name} has been muted')

    # Store muted user data
    if member.id not in data['users']:
        data['users'][member.id] = {'muted': True}
    else:
        data['users'][member.id]['muted'] = True
    save_data(data)

# Unmute command
@bot.command()
@commands.has_permissions(manage_roles=True)
async def unmute(ctx, member: discord.Member):
    muted_role = discord.utils.get(ctx.guild.roles, name='Muted')
    if muted_role in member.roles:
        await member.remove_roles(muted_role)
        await ctx.send(f'{member.name} has been unmuted')
        
        # Update user data
        if member.id in data['users']:
            data['users'][member.id]['muted'] = False
            save_data(data)
    else:
        await ctx.send(f'{member.name} is not muted')

# Warn command
@bot.command()
@commands.has_permissions(kick_members=True)
async def warn(ctx, member: discord.Member, *, reason=None):
    if member == ctx.author:
        await ctx.send('You cannot warn yourself!')
        return
    
    # Initialize warnings for the user if not present
    if member.id not in data['users']:
        data['users'][member.id] = {'warnings': 1}
    else:
        if 'warnings' not in data['users'][member.id]:
            data['users'][member.id]['warnings'] = 1
        else:
            data['users'][member.id]['warnings'] += 1
    
    save_data(data)
    await ctx.send(f'{member.name} has been warned. Total warnings: {data["users"][member.id]["warnings"]}')

# Welcome command to set welcome message
@bot.command()
@commands.has_permissions(administrator=True)
async def welcome(ctx, *, message):
    data['welcome_messages'][ctx.guild.id] = message
    save_data(data)
    await ctx.send('Welcome message set')

# Event for new member join
@bot.event
async def on_member_join(member):
    guild_id = member.guild.id
    if guild_id in data['welcome_messages']:
        welcome_message = data['welcome_messages'][guild_id]
        await member.send(welcome_message)

# Run the bot
bot.run(TOKEN)